x = 1
print(1 is x)