t = (42, )
print(t[0])
