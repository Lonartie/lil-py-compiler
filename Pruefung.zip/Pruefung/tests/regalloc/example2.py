v = 1
w = 42
x = v + 7
y = x
z = x + w
print(z + (- y))
