a = 1
b = 1
c = 1
print(a + b)
print(a + b + c)
