a = 1
b = 0
print(a)
print(b)
c = 2
print(a + c)
