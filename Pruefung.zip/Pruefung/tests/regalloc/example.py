x = input_int()
y = input_int()
print((x + y) + 42)
