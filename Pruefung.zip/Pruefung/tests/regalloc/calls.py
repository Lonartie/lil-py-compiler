a = 1
c = input_int()
b = 1
print(a + b + c)
