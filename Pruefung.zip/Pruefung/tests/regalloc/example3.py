a = input_int()
b = 1
print(a + b)
c = input_int()
d = 1
print(a + c + d)
e = input_int()
print(a + b + c + d + e)
