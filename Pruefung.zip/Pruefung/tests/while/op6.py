x = 0 > 1 and True
x = 0 >= 1 and True
x = 1 < 0 and True
x = 1 <= 0 and True
x = 1 == 0 and True
print(0)
