while False:
    print(0)
while 1 == 2:
    print(0)
print(1)
