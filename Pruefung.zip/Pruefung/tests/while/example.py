sum = 0
i = 5
while i > 0:
    sum = sum + i
    i = i - 1
print(sum)
