a = input_int()
b = 1
c = input_int()
while a < c:
    a = a + b
print(a)
