a = 0
c = input_int()
b = 0
while b < 2:
    a = 5 + c
    b = b + 1
print(a)
