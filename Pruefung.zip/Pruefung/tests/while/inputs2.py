a = 1
b = input_int()
c = 1
d = 1
e = input_int()
while b < e:
    b = b + a + c + d
print(b)
