x = 10
while x >= 1:
    x = x - 1
print(x)
