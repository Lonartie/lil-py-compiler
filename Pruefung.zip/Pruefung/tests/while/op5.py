x = 10
while x != 0:
    x = x - 1
print(x)
