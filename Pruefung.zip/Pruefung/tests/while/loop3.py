x = 20
while x > 0:
    y = 2
    while y != 0:
        y = y - 1
    x = x - 1
print(x)
