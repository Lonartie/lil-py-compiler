x = 1
y = x + x
y = y + 1
y = 1 + y
print(x + y)