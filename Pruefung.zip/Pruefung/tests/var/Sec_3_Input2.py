x = input_int() + input_int() + input_int()
print(x)
print(x)
print(x)
