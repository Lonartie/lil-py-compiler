print(40 + 2)
