x = 2
y = 48 - x - 4
print(y)