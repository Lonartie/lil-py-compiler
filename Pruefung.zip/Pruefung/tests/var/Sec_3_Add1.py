x = 40 + (4 + 4)
print(x + 2)