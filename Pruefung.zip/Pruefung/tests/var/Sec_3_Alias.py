x = 42
y = 0
x = x
x = x
y = y
y = y
x = x
print(x + y + y + y)