x = input_int()
y = input_int()
z = x + y
print(z + input_int())
