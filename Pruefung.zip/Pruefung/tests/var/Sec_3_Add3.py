x = 2
y = 2
z = x + y
print(z)