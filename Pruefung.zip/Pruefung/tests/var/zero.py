print(0)
