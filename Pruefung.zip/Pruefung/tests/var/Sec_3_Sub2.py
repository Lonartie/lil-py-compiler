x = 6
y = x - 2
y = -2 + y
print(y - 2)