print((4 if True else 0) + (0 if (False and True) else 2))
