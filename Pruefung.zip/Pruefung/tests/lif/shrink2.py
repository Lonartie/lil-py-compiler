if False and True:
    print(0)
else:
    print(1)
