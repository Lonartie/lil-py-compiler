x = input_int()
y = input_int()
if x == 0:
    if y == 1:
        print(1 + 2 + 3 - 4)
    else:
        print(1 - 2 - 3)
else:
    a = 1
    b = 1
    c = 1
    d = 1
    e = 1
    f = 1
    g = 1
    h = 1
    i = 1
    j = 1
    k = -10 if x == 1 else 10
    print(a + b + c + d + e + f + g + h + i + j + k)
