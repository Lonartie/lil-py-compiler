print(1 if True else 0)
