if True or False:
    print(1)
else:
    print(0)
