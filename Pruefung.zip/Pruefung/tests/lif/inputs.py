if input_int() == input_int() and input_int() >= input_int():
    print(42 + input_int())
else:
    print(1 if input_int() == 0 else 42)
